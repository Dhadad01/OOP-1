public class VoidRenderer implements Renderer{
    /**
     *
     * doesnt show anything - just to supply renderer when we dont need to show
     */
    @Override
    public void renderBoard(Board board){}
}
