enum Mark{BLANK, X, O}
//3 possible marks on the board


